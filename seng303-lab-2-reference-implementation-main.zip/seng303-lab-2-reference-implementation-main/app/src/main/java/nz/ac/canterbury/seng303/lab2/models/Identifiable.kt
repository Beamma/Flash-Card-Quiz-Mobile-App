package nz.ac.canterbury.seng303.lab2.models

interface Identifiable {
    fun getIdentifier(): Int
}